<?php
//author samik
$nameWebsite = (strtolower(substr(getenv('HTTP_HOST'), 0, 4)) == 'www.') ? substr(getenv('HTTP_HOST'), 4) : getenv('HTTP_HOST');
$keyParser = md5($nameWebsite.'kodik-vv1.0.evo');
echo 'Ваш ключ: '.$keyParser;
//author samik
?>
